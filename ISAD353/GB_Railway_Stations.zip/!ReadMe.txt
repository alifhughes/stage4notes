The enclosed CSV and KML files contain point data for railway stations in Great Britain.

The data is derived from the July 2013 update of Ordnance Survey's Meridian 2 product. There is more information about Meridian 2 online here:

http://www.ordnancesurvey.co.uk/business-and-government/products/meridian2.html

This data is re-usable under the OS OpenData licence, a copy of which is enclosed and also available online here:

http://www.ordnancesurvey.co.uk/docs/licences/os-opendata-licence.pdf

-- Owen Boswarva, 08/11/2013